const { app, BrowserWindow, ipcMain, Menu, shell, dialog } = require('electron');
const path = require('path');
const fs   = require('fs');
const os   = require('os');

const userDataPath   = app.getPath('userData');
const bookmarksPath  = path.join(userDataPath, 'bookmarks.json');
const historyPath    = path.join(userDataPath, 'history.json');
const settingsPath   = path.join(userDataPath, 'settings.json');
const downloadsPath  = path.join(userDataPath, 'downloads.json');

const DEFAULT_SETTINGS = {
  theme: 'dark', homepage: 'https://www.google.com', searchEngine: 'google',
  customColors: null, quicklinks: null, session: null,
  privateMode: false,
  downloadPath: app.getPath('downloads'),
};

function loadJSON(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}
function saveJSON(p, d) { fs.writeFileSync(p, JSON.stringify(d, null, 2)); }

function initData() {
  if (!fs.existsSync(bookmarksPath)) saveJSON(bookmarksPath, []);
  if (!fs.existsSync(historyPath))   saveJSON(historyPath, []);
  if (!fs.existsSync(settingsPath))  saveJSON(settingsPath, DEFAULT_SETTINGS);
  if (!fs.existsSync(downloadsPath)) saveJSON(downloadsPath, []);
}

let win;

function createWindow() {
  const s = loadJSON(settingsPath, DEFAULT_SETTINGS);
  const isPrivate = s.privateMode === true;

  const opts = {
    width: 1400, height: 900, minWidth: 800, minHeight: 600,
    frame: false,
    webPreferences: {
      preload: path.join(__dirname, '../preload/preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      sandbox: false,
    },
    backgroundColor: isPrivate ? '#0d0d1f' : '#0f0f1a',
    show: false,
  };

  // Private mode: use in-memory partition (no disk cache/cookies/history)
  if (isPrivate) {
    opts.webPreferences.partition = 'in-memory-only';
  }

  win = new BrowserWindow(opts);
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, '../renderer/index.html'));
  Menu.setApplicationMenu(null);

  // Handle downloads
  win.webContents.session.on('will-download', (e, item) => {
    const cfg = loadJSON(settingsPath, DEFAULT_SETTINGS);
    const dlDir = cfg.downloadPath || app.getPath('downloads');

    // Ensure directory exists
    if (!fs.existsSync(dlDir)) {
      try { fs.mkdirSync(dlDir, { recursive: true }); } catch {}
    }

    const savePath = path.join(dlDir, item.getFilename());
    item.setSavePath(savePath);

    const dlEntry = {
      id: Date.now(),
      filename: item.getFilename(),
      url: item.getURL(),
      path: savePath,
      size: 0,
      received: 0,
      status: 'progressing',
      startedAt: new Date().toISOString(),
    };

    item.on('updated', (_, state) => {
      dlEntry.received = item.getReceivedBytes();
      dlEntry.size = item.getTotalBytes();
      dlEntry.status = state;
      win?.webContents.send('download-update', { ...dlEntry });
    });

    item.once('done', (_, state) => {
      dlEntry.status = state;
      dlEntry.size = item.getTotalBytes();
      dlEntry.received = dlEntry.size;
      dlEntry.finishedAt = new Date().toISOString();

      // Only persist download history if NOT private mode
      if (!isPrivate) {
        const list = loadJSON(downloadsPath, []);
        list.unshift({ ...dlEntry });
        saveJSON(downloadsPath, list.slice(0, 500));
      }
      win?.webContents.send('download-done', { ...dlEntry });
    });

    win?.webContents.send('download-start', { ...dlEntry });
  });

  // webview downloads: forward will-download from webview sessions
  app.on('session-created', (sess) => {
    sess.on('will-download', (e, item) => {
      const cfg = loadJSON(settingsPath, DEFAULT_SETTINGS);
      const dlDir = cfg.downloadPath || app.getPath('downloads');
      if (!fs.existsSync(dlDir)) {
        try { fs.mkdirSync(dlDir, { recursive: true }); } catch {}
      }
      const savePath = path.join(dlDir, item.getFilename());
      item.setSavePath(savePath);

      const dlEntry = {
        id: Date.now(), filename: item.getFilename(),
        url: item.getURL(), path: savePath,
        size: 0, received: 0, status: 'progressing',
        startedAt: new Date().toISOString(),
      };

      item.on('updated', (_, state) => {
        dlEntry.received = item.getReceivedBytes();
        dlEntry.size = item.getTotalBytes();
        dlEntry.status = state;
        win?.webContents.send('download-update', { ...dlEntry });
      });

      item.once('done', (_, state) => {
        dlEntry.status = state;
        dlEntry.size = item.getTotalBytes();
        dlEntry.received = dlEntry.size;
        dlEntry.finishedAt = new Date().toISOString();
        if (!isPrivate) {
          const list = loadJSON(downloadsPath, []);
          list.unshift({ ...dlEntry });
          saveJSON(downloadsPath, list.slice(0, 500));
        }
        win?.webContents.send('download-done', { ...dlEntry });
      });

      win?.webContents.send('download-start', { ...dlEntry });
    });
  });

  win.on('close', (e) => {
    if (win._readyToClose) return;
    e.preventDefault();
    win.webContents.send('before-close');
  });
  win.on('closed', () => { win = null; });
  win.on('enter-full-screen', () => win.webContents.send('fullscreen', true));
  win.on('leave-full-screen',  () => win.webContents.send('fullscreen', false));
}

app.whenReady().then(() => { initData(); createWindow(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!win) createWindow(); });

// Window controls
ipcMain.on('win-minimize',   () => win?.minimize());
ipcMain.on('win-maximize',   () => { if (!win) return; win.isMaximized() ? win.unmaximize() : win.maximize(); });
ipcMain.on('win-fullscreen', () => win?.setFullScreen(!win.isFullScreen()));
ipcMain.on('win-close', () => { if (win) win.close(); });

ipcMain.on('save-session-sync', (_, session) => {
  if (!win) return;
  try {
    const s = loadJSON(settingsPath, DEFAULT_SETTINGS);
    s.session = session;
    saveJSON(settingsPath, s);
  } catch(e) { console.error('session save failed', e); }
  win._readyToClose = true;
  win.close();
});

// Bookmarks
ipcMain.handle('get-bookmarks',   () => loadJSON(bookmarksPath, []));
ipcMain.handle('add-bookmark',    (_, b) => {
  const list = loadJSON(bookmarksPath, []);
  if (!list.find(x => x.url === b.url)) list.unshift({ ...b, id: Date.now() });
  saveJSON(bookmarksPath, list); return list;
});
ipcMain.handle('remove-bookmark', (_, url) => {
  const list = loadJSON(bookmarksPath, []).filter(b => b.url !== url);
  saveJSON(bookmarksPath, list); return list;
});

// History (skip in private mode)
ipcMain.handle('get-history', () => loadJSON(historyPath, []).slice(0, 300));
ipcMain.handle('add-history', (_, entry) => {
  const s = loadJSON(settingsPath, DEFAULT_SETTINGS);
  if (s.privateMode) return []; // don't save in private mode
  const list = loadJSON(historyPath, []);
  if (!list.slice(0, 5).some(h => h.url === entry.url))
    list.unshift({ ...entry, id: Date.now(), at: new Date().toISOString() });
  const t = list.slice(0, 1000); saveJSON(historyPath, t); return t.slice(0, 300);
});
ipcMain.handle('clear-history', () => { saveJSON(historyPath, []); return []; });

// Settings
ipcMain.handle('get-settings', () => {
  const s = loadJSON(settingsPath, DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...s };
});
ipcMain.handle('save-settings', (_, s) => {
  saveJSON(settingsPath, s);
  return s;
});

// Downloads
ipcMain.handle('get-downloads', () => loadJSON(downloadsPath, []));
ipcMain.handle('clear-downloads', () => { saveJSON(downloadsPath, []); return []; });
ipcMain.handle('open-file',   (_, p) => shell.openPath(p));
ipcMain.handle('show-in-folder', (_, p) => { shell.showItemInFolder(p); return true; });
ipcMain.handle('choose-download-path', async () => {
  const result = await dialog.showOpenDialog(win, {
    properties: ['openDirectory'],
    title: 'ダウンロード保存先を選択',
  });
  if (result.canceled || !result.filePaths.length) return null;
  return result.filePaths[0];
});

// Restart with private mode toggle
ipcMain.on('restart-app', () => {
  win._readyToClose = true;
  app.relaunch();
  app.quit();
});
